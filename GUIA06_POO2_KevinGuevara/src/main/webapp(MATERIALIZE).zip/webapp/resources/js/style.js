function CNB(){
		document.getElementById('img1').src = "img/1B1.png";
		document.getElementById('img2').src = "img/1B2.png";
		document.getElementById('img3').src = "img/1B3.png";
		document.getElementById('img4').src = "img/1B4.png";
	}
	function JUVENILES(){
		document.getElementById('img1').src = "img/2B1.png";
		document.getElementById('img2').src = "img/2B2.png";
		document.getElementById('img3').src = "img/2B3.png";
		document.getElementById('img4').src = "img/2B4.png";
	}
	function TRANSPARENCIA(){
		document.getElementById('img1').src = "img/3B1.png";
		document.getElementById('img2').src = "img/3B2.png";
		document.getElementById('img3').src = "img/3B3.png";
		document.getElementById('img4').src = "img/3B4.png";
	}
	function BIBLIOTECA(){
		document.getElementById('img1').src = "img/4B1.png";
		document.getElementById('img2').src = "img/4B2.png";
		document.getElementById('img3').src = "img/4B3.png";
		document.getElementById('img4').src = "img/4B4.png";
	}
	function reestablecer(){
		document.getElementById('img1').src = "img/1A.jpg";
		document.getElementById('img2').src = "img/2A.jpg";
		document.getElementById('img3').src = "img/3A.jpg";
		document.getElementById('img4').src = "img/4A.jpg";
	}